from django.http import HttpResponse

def home(request):
    return HttpResponse("Привет, это первая лабораторная по Django!")
